package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.URLName;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

import com.sun.mail.imap.IMAPStore;

public class Mail2014302580075 implements IMailService{
	
	private Session session;
	private Properties props;
	private IMAPStore store;
	private Folder folder;
	
	/**
	 * ������������SMTP������
	 * @throws MessagingException ��ʼ���������쳣
	 */
	@Override
	public void connect() throws MessagingException {
		
		props=new Properties();
		props.setProperty("mail.smtp.auth", "true");
		props.setProperty("mail.transport.protocol", "smtp");
		props.setProperty("mail.host", "smtp.sina.com");
		 session=Session.getInstance(props, 
				new Authenticator() {
			
					protected PasswordAuthentication getPasswordAuthentication()
					{
						return new PasswordAuthentication("summerainx@sina.com","cqmyg123456");
					}
				}
				
				);
//		session.setDebug(true);
	}
	/**
	 * ���ڷ��͵����ʼ�����������Ϣ
	 * @param recipient �ռ��������ַ
     * @param subject �ʼ�����
     * @param content �ʼ�����
     * @throws MessagingException �����ʼ�����
	 */
	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// TODO �Զ����ɵķ������
		Message message=new MimeMessage(session);
		message.setFrom(new InternetAddress("summerainx@sina.com"));
		message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
		message.setSubject(subject);
		message.setContent(content, "text/plain");
		Transport.send(message);
		
		
	}
	/**
	 * �����ʼ��Ƿ��ͳɹ�
	 * @return boolean
	 * ���Ϊtrue�����ͳɹ�������ʧ�ܡ�
	 * @throws MessagingException �޷����ʷ�����
	 */
	@Override
	public boolean listen() throws MessagingException {
		URLName url=new URLName("imap", "imap.sina.com", 143, null, "summerainx@sina.com", "cqmyg123456");
		props.setProperty("mail.store.protocol", "imap");
		props.setProperty("mail.imap.auth", "true");
		props.setProperty("mail.host", "imap.sina.com");
		session=Session.getInstance(props);
	    store=new IMAPStore(session, url);
	    store.connect();
		folder=store.getFolder("INBOX");
		folder.open(Folder.READ_ONLY);
		if (folder.getNewMessageCount()>0) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * ��ȡ�ʼ���Ϣ
	 * @return String 
	 * @throws MessagingException ��ȡ�ʼ��쳣 
	 * @throws IOException IO�������쳣
	 */
	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		// TODO �Զ����ɵķ������
		Message message[]=folder.getMessages();
		String info=null;
		for (int i = 0; i < message.length; i++) {
			info=info+message[i].getContent()+"\n";
			
		}
		folder.close(true);
		store.close();
		return info;
	}

}
